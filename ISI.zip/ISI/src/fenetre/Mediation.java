package fenetre;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.BorderFactory;
import javax.swing.ComboBoxModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.Border;
/**
 * @author ${AMARA}
 *
 */
public class Mediation extends JFrame implements ActionListener{
	String user,passwd,url;
	fond pan=new fond();
	String x;
	JComboBox c=new JComboBox();
	JComboBox hot=new JComboBox();
	JCheckBox k=new JCheckBox("OUI");
	JCheckBox h1=new JCheckBox("OUI");
	JCheckBox k2=new JCheckBox("OUI");
	JLabel la1=new JLabel("Velib");
	JLabel info=new JLabel("Vues Disponible : Filme-Wifi | Film-Velib | Film-hotel");
	JLabel la2=new JLabel("WI-FI");
	JLabel ho=new JLabel("HOTEL");
	Font font = new Font("Arial",Font.BOLD,16);
	JButton b=new JButton("Quiter");

JButton b1=new JButton("Recherche");
JTextArea tx = new JTextArea("RESULTATS DE LA RECHERCHE",10000,10);	
JLabel la=new JLabel("Code Postal Film");
	public Mediation(String user,String passwd,String url) {
		this.user=user;
		this.passwd=passwd;
		this.url=url;
		info.setFont(font);
		info.setForeground(new Color(255,0,0));
		this.setTitle("Mapping ISI");
	    this.setSize(1000,500);
	    this.setLocationRelativeTo(null);
	    pan.setLayout(new GridBagLayout());
	    tx.setLineWrap(true);
	    tx.setWrapStyleWord(true);
	    JScrollPane sc = new JScrollPane(tx, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
	    tx.setEditable(true);
	    tx.setPreferredSize(new Dimension(100, 100));

	    c.setPreferredSize(new Dimension(100, 20));
	    b1.setPreferredSize(new Dimension(100, 20));

	    c.addItem("Tout Les Ardt");
	    hot.addItem("Nombre etoiles");

	    GridBagConstraints gbc = new GridBagConstraints();
	    
	    gbc.gridx = 0;
	    gbc.gridy = 0;
	    gbc.gridheight = 1;
	    gbc.gridwidth = 1;
	    pan.add(la, gbc);
	    gbc.gridx = 3;
	    pan.add(c, gbc);
	    
	    gbc.gridwidth = GridBagConstraints.REMAINDER;
	
	    
	    gbc.gridx = 0;
	    gbc.gridy = 1;
	    gbc.gridwidth = 1;
	    gbc.gridheight = 1;
	    pan.add(la1, gbc);
	    gbc.gridx = 2;
	    pan.add(k, gbc);
	    
	    
	    gbc.gridwidth = GridBagConstraints.REMAINDER;
	    gbc.gridx = 0;
	    gbc.gridy = 2;
	    gbc.gridwidth = 1;
	    gbc.gridheight = 1;
	    pan.add(la2, gbc);
	    gbc.gridx = 2;
	    pan.add(k2, gbc);
	    gbc.gridx = 4;
	    pan.add(info, gbc);
	    	    
	    gbc.gridwidth = GridBagConstraints.REMAINDER;
	    
	    gbc.gridx = 0;
	    gbc.gridy = 4;
	    gbc.gridwidth = 1;
	    gbc.gridheight =1;
	    pan.add(ho, gbc);
	    gbc.gridx = 1;
	    pan.add(h1, gbc);
	  
	    gbc.gridx = 3;
	    pan.add(hot, gbc);
	    
	    gbc.gridwidth = GridBagConstraints.REMAINDER;
	    gbc.gridx = 0;
	    gbc.gridy = 5;
	    gbc.gridwidth = 1;
	    gbc.gridheight =1;
	    pan.add(b1, gbc);
	    gbc.gridx = 4;
	    pan.add(b, gbc);


	    gbc.gridwidth = GridBagConstraints.REMAINDER;
	    
	    
	    gbc.gridx = 0;
	    gbc.gridy = 6;
	    gbc.weightx = 1;
	    gbc.weighty = 1;
	    gbc.gridwidth = 5;
	    gbc.gridheight = 5;
	    gbc.fill = GridBagConstraints.BOTH;
	    //gbc.fill = GridBagConstraints.VERTICAL;
	    //gbc.gridwidth = GridBagConstraints.REMAINDER;

	    pan.add(sc,gbc);
	    b.addActionListener(this);

	    b1.addActionListener(this);
	    pan.setFocusable(true);
	 	    
	    this.setContentPane(pan);
	   
	    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    this.setVisible(true);

	}
					
	

			      
	     
	 
	
	public void remplir() {
		try {
	     Connection conn = DriverManager.getConnection(url, user,passwd);

	     Statement state = conn.createStatement();
	 	state.executeUpdate("DROP TABLE IF EXISTS velib,wifi,film,hotel cascade");
     	
    	BufferedReader br = new BufferedReader(new InputStreamReader( new FileInputStream("src/tournagesdefilmsparis2011.csv"), "UTF8"));
    	BufferedReader br1 = new BufferedReader(new InputStreamReader( new FileInputStream("src/wifi.csv"), "UTF8"));
    	BufferedReader br2 = new BufferedReader(new InputStreamReader( new FileInputStream("src/velib.csv"), "UTF8"));
    	BufferedReader br3 = new BufferedReader(new InputStreamReader( new FileInputStream("src/hotel.csv"), "UTF8"));

    	
    	String line="";
     	String line1="";
    	String line2="";
    	String line3="";

        br.readLine(); 

        line = br.readLine();
        line1 = br1.readLine();
        line2 = br2.readLine();
        line3=br3.readLine();
        
       String G1[]=line.split(";");
       String G2[]=line1.split(";");
       String G3[]=line2.split(";");
       String G4[]=line3.split(";");

    	String query="CREATE TABLE film("+G1[0]+" VARCHAR(70),"+G1[1]+" VARCHAR(70),"+G1[2]+" VARCHAR(70),"+G1[3]+" VARCHAR(70),"+G1[4]+" VARCHAR(70),"+G1[5]+" INT,"+G1[6]+" VARCHAR(70),"+G1[7]+" VARCHAR(70),"+G1[8]+" VARCHAR(70))";
    	String query1="CREATE TABLE wifi("+G2[0]+" VARCHAR(100),"+G2[1]+" VARCHAR(100),"+G2[2]+" VARCHAR(100),"+G2[3]+" VARCHAR(100),"+G2[4]+" INT,"+G2[5]+" VARCHAR(100),"+G2[6]+" VARCHAR(100))";
    	String query2="CREATE TABLE velib("+G3[0]+" VARCHAR(100),"+G3[1]+" VARCHAR(100),"+G3[2]+" VARCHAR(100),"+G3[3]+" VARCHAR(100),"+G3[4]+" INT,"+G3[5]+" VARCHAR(100),"+G3[6]+" VARCHAR(100),"+G3[7]+" VARCHAR(100),"+G3[8]+" VARCHAR(100))";
    	String query3="CREATE TABLE hotel("+G4[0]+" VARCHAR(100),"+G4[1]+" VARCHAR(100),"+G4[2]+" VARCHAR(100),"+G4[3]+" VARCHAR(100),"+G4[4]+" VARCHAR(100),"+G4[5]+" VARCHAR(100),"+G4[6]+" INT,"+G4[7]+" VARCHAR(100),"+G4[8]+" VARCHAR(100),"+G4[9]+" VARCHAR(100),"+G4[10]+" VARCHAR(220),"+G4[11]+" VARCHAR(100),"+G4[12]+" VARCHAR(100),"+G4[13]+" VARCHAR(100))";
       System.out.println(G4.length);
    	
    	state.executeUpdate(query);
     	state.executeUpdate(query1);
     	state.executeUpdate(query2);
     	state.executeUpdate(query3);

         
     	 while ((line1 = br1.readLine()) != null) {
         	String don1[]=line1.split(";");         	
         	for(int i=0;i<don1.length;i++) {
         		if(don1[i].contains("'")==true) {         		
         			don1[i]=don1[i].replace("'","''");    			
         		}
         	}        
         	state.executeUpdate("INSERT INTO wifi VALUES('"+don1[0]+"','"+don1[1]+"','"+don1[2]+"','"+don1[3]+"','"+don1[4]+"','"+don1[5]+"','"+don1[6]+"')");        	
         	}
     	
         
        while ((line = br.readLine()) != null) {
        	String don[]=line.split(";");        	
        	for(int i=0;i<don.length;i++) {
        		if(don[i].contains("'")==true) {      		
        			don[i]=don[i].replace("'","''");    			
        		}
        	}      	
        	if(don.length==9) {
        	state.executeUpdate("INSERT INTO film VALUES('"+don[0]+"','"+don[1]+"','"+don[2]+"','"+don[3]+"','"+don[4]+"','"+don[5]+"','"+don[6]+"','"+don[7]+"','"+don[8]+"')");       	
        	}}
       
        
        while ((line2 = br2.readLine()) != null) {
         	String don2[]=line2.split(";");         	
         	for(int i=0;i<don2.length;i++) {
         		if(don2[i].contains("'")==true) {        		
         			don2[i]=don2[i].replace("'","''");    			
         		}
         	}        
         	state.executeUpdate("INSERT INTO velib VALUES('"+don2[0]+"','"+don2[1]+"','"+don2[2]+"','"+don2[3]+"','"+don2[4]+"','"+don2[5]+"','"+don2[6]+"','"+don2[7]+"','"+don2[8]+"')");         	
         	}     	        
        
        while ((line3 = br3.readLine()) != null) {
         	String don3[]=line3.split(";");         	
         	for(int i=0;i<don3.length;i++) {
         		if(don3[i].contains("'")==true) {        		
         			don3[i]=don3[i].replace("'","''");    			
         		}
         	}
         	//System.out.println(don3.length);
         	if(don3.length==14) {
            state.executeUpdate("INSERT INTO hotel VALUES('"+don3[0]+"','"+don3[1]+"','"+don3[2]+"','"+don3[3]+"','"+don3[4]+"','"+don3[5]+"','"+don3[6]+"','"+don3[7]+"','"+don3[8]+"','"+don3[9]+"','"+don3[10]+"','"+don3[11]+"','"+don3[12]+"','"+don3[13]+"')");         	
         	}}     	        
        
       System.out.println("insertion des données faite");

	      state.close();
		} catch (Exception e) {
		      e.printStackTrace();
		    }     
      
	}        
	 
	public void deldon() {
	 Connection conn;
	try {
		conn = DriverManager.getConnection(url, user,passwd);
	     Statement state = conn.createStatement();

		String quer="DROP TABLE velib,wifi,film,hotel cascade";

    	state.executeUpdate(quer);
	      state.close();
     System.out.println("les données sont suprimmé de la BDD");
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
		
			
	public void VueFilmHotel (String eto,String ar) {
		try {
		     

			  Connection conn = DriverManager.getConnection(url, user,passwd);
		      Statement state = conn.createStatement();
			/* String crvue="CREATE OR REPLACE VIEW vue_utili(titre_fi,adr_fi,vel_adr,vel_nm,wi_adr,wi_site,hot_nom,hot_adr,hot_phone,hot_site) AS SELECT titre,adresse,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL FROM film"
			 		                        + "UNION SELECT NULL,NULL,address,name,NULL,NULL,NULL,NULL,NULL,NULL FROM Velib"
			 		                        + "UNION SELECT NULL,NULL,NULL,NULL,adresse,nom_site,NULL,NULL,NULL,NULL FROM wifi"
			 		                        + "UNION SELECT NULL,NULL,NULL,NULL,NULL,NULL,nom_commercial,adresse,telephone,site_internet FROM hotel ";*/
				String crvue="create OR REPLACE view Vuefilm_hotel (titre_film,film_adresse,film_ardt,hotel_nom,hotel_phone,hotel_siteWeb) "
						+ "as select f.titre,f.adresse,f.ardt,h.nom_commercial,h.telephone,h.site_internet from film f,hotel h where f.ardt=h.code_postal AND f.ardt="+ar+" AND h.classement='"+eto+"'";

		      state.executeUpdate(crvue);
		      String query="select * from Vuefilm_hotel";
			  ResultSet result = state.executeQuery(query);
			  String nom1="";
			  String nom="        titre_film                |                film_adresse             |               film_ardt              |               hotel_nom             |            hotel_phone           |            hotel_siteWeb          \n ";
              
		      while(result.next()){ 

			          nom1 = result.getString("titre_film")+" \t "+result.getString("film_adresse")+" \t "+result.getString("film_ardt")+" \t "+result.getString("hotel_nom")+" \t "+result.getString("hotel_phone")+" \t "+result.getString("hotel_siteWeb")+"\n";
			           nom=nom+nom1;
			           tx.setText(nom);
		      }
		  System.out.println("reussii");
		      result.close();			
		      state.close();

			} catch (Exception e) {
			      e.printStackTrace();
			    } 
	}
		
	public void VueFilmVelib (String ar) {
		try {
		     

			  Connection conn = DriverManager.getConnection(url, user,passwd);
		      Statement state = conn.createStatement();
			/* String crvue="CREATE OR REPLACE VIEW vue_utili(titre_fi,adr_fi,vel_adr,vel_nm,wi_adr,wi_site,hot_nom,hot_adr,hot_phone,hot_site) AS SELECT titre,adresse,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL FROM film"
			 		                        + "UNION SELECT NULL,NULL,address,name,NULL,NULL,NULL,NULL,NULL,NULL FROM Velib"
			 		                        + "UNION SELECT NULL,NULL,NULL,NULL,adresse,nom_site,NULL,NULL,NULL,NULL FROM wifi"
			 		                        + "UNION SELECT NULL,NULL,NULL,NULL,NULL,NULL,nom_commercial,adresse,telephone,site_internet FROM hotel ";*/
			 		
			 		
				String crvue="create OR REPLACE view Vuefilm_velib (titre_film,film_adresse,film_ardt,velib_nom,velib_adresse) as select f.titre,f.adresse,f.ardt,v.name,v.address from film f,velib v where f.ardt=v.cp AND f.ardt="+ar+" ";

		      state.executeUpdate(crvue);
		      String query="select * from Vuefilm_velib";
			  ResultSet result = state.executeQuery(query);
			  String nom1="";
			  String nom="        titre_film                |                film_adresse             |               film_ardt              |               velib_nom             |            velib_adresse           \n ";
              
		      while(result.next()){ 

			          nom1 = result.getString("titre_film")+" \t "+result.getString("film_adresse")+" \t "+result.getString("film_ardt")+" \t "+result.getString("velib_nom")+" \t "+result.getString("velib_adresse")+"\n";
			           nom=nom+nom1;
			           tx.setText(nom);
		      }
		  System.out.println("reussii");
		      result.close();			
		      state.close();

			} catch (Exception e) {
			      e.printStackTrace();
			    } 
	}
	
    public void VueFilmWifi (String ar) {
			try {			     
				  Connection conn = DriverManager.getConnection(url, user,passwd);
			      Statement state = conn.createStatement();
					String crvue="create OR REPLACE view Vuefilm_wifi (titre_film,film_adresse,film_ardt,wifi_nom,wifi_adresse)"
							+ " as select f.titre,f.adresse,f.ardt,w.nom_site,w.adresse from film f,wifi w where f.ardt=w.arrondissement AND f.ardt="+ar+" ";
			      state.executeUpdate(crvue);
			      String query="select * from Vuefilm_wifi";
				  ResultSet result = state.executeQuery(query);
				  String nom1="";
				  String nom="        titre_film                |                film_adresse             |               film_ardt              |               wifi_nom             |            wifi_adresse           \n ";

			      while(result.next()){ 

			          nom1 = result.getString("titre_film")+" \t "+result.getString("film_adresse")+" \t "+result.getString("film_ardt")+" \t "+result.getString("wifi_nom")+" \t "+result.getString("wifi_adresse")+"\n";
				           nom=nom+nom1;
				           tx.setText(nom);
			      }
			      result.close();			
			      state.close();

				} catch (Exception e) {
				      e.printStackTrace();
				    } 
		}
   
    public void VueFilmWifiVelib (String ar) {
		try {
		     

			  Connection conn = DriverManager.getConnection(url, user,passwd);
		      Statement state = conn.createStatement();
		
			 		
				String crvue="create OR REPLACE view Vuefilm_wifi_Velib (titre_film,film_adresse,film_ardt,wifi_nom,wifi_adresse,velib_nom,velib_adresse)"
						+ " as select f.titre,f.adresse,f.ardt,w.nom_site,w.adresse,v.name,v.address from film f,wifi w,velib v";

		     // state.executeUpdate(crvue);
		      String query="select f.titre as titro,f.adresse as adresso,f.ardt as ardeto, w.nom_site as sito,w.adresse as adresse_wifi,v.name as namo,v.address as addresso from film f,velib v,wifi w where f.ardt=v.cp AND f.ardt=w.arrondissement AND f.ardt="+ar+"";
			  ResultSet result = state.executeQuery(query);
			  String nom1="";
			  String nom="        titre_film     |     film_adresse        |        film_ardt         |         wifi_nom         |      adresse_wifi    |        velib_nom      |        velib_address       \n ";

		      while(result.next()){ 

			          nom1 = result.getString("titro")+"\t"+result.getString("adresso")+
			        		  "\t"+result.getString("ardeto")+"\t"+result.getString("sito")+"\t"+result.getString("adresse_wifi")+"\t"+result.getString("namo")+"\t"+result.getString("addresso")+"\n";
			           nom=nom+nom1;
			           tx.setText(nom);}
		      result.close();			
		      state.close();

			} catch (Exception e) {
			      e.printStackTrace();
			    } 
	}
    public void VueFilmWifiVelibHotel (String eto,String ar) {
		try {
		     

			  Connection conn = DriverManager.getConnection(url, user,passwd);
		      Statement state = conn.createStatement();
			/* String crvue="CREATE OR REPLACE VIEW vue_utili(titre_fi,adr_fi,vel_adr,vel_nm,wi_adr,wi_site,hot_nom,hot_adr,hot_phone,hot_site) AS SELECT titre,adresse,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL FROM film"
			 		                        + "UNION SELECT NULL,NULL,address,name,NULL,NULL,NULL,NULL,NULL,NULL FROM Velib"
			 		                        + "UNION SELECT NULL,NULL,NULL,NULL,adresse,nom_site,NULL,NULL,NULL,NULL FROM wifi"
			 		                        + "UNION SELECT NULL,NULL,NULL,NULL,NULL,NULL,nom_commercial,adresse,telephone,site_internet FROM hotel ";*/
			 		
			 		
				String crvue="create OR REPLACE view Vuefilm_wifi_Velib (titre_film,film_adresse,film_ardt,wifi_nom,wifi_adresse,velib_nom,velib_adresse)"
						+ " as select f.titre,f.adresse,f.ardt,w.nom_site,w.adresse,v.name,v.address from film f,wifi w,velib v";

		     // state.executeUpdate(crvue);
		      String query="select f.titre as titro,f.adresse as adresso,f.ardt as ardeto, w.nom_site as sito,w.adresse as adresse_wifi,v.name as namo,v.address as addresso,h.nom_commercial as Hot_nom,h.site_internet as Siteweb"
		      		+ " from film f,velib v,wifi w,hotel h where f.ardt=v.cp AND f.ardt=w.arrondissement AND f.ardt=h.code_postal AND f.ardt="+ar+" AND h.classement='"+eto+"'";
			  ResultSet result = state.executeQuery(query);
			  String nom1="";
			  String nom="        titre_film     |     film_adresse    |      film_ardt       |      wifi_nom       |       velib_nom      |     Hot_nom   |    ho_Siteweb   \n ";

		      while(result.next()){ 

			          nom1 = result.getString("titro")+"\t"+result.getString("adresso")+
			        		  "\t"+result.getString("ardeto")+"\t"+result.getString("sito")+"\t"+result.getString("namo")+"\t"+result.getString("Hot_nom")+"\t"+result.getString("Siteweb")+"\n";
			           nom=nom+nom1;
			           tx.setText(nom);}
		       System.out.println("reussii");
		      result.close();			
		      state.close();

			} catch (Exception e) {
			      e.printStackTrace();
			    } 
	}
		
    public void etoils() {
		try {		   
			  Connection conn = DriverManager.getConnection(url, user,passwd);
		      Statement state = conn.createStatement();			
		      String query1="select distinct(classement) as etoils from hotel";
			  ResultSet result1 = state.executeQuery(query1);
			  String nom1="";		  
		      while(result1.next()){ 
		          nom1 = result1.getString("etoils");
		              hot.addItem(nom1);	      }
		      result1.close();			
		      state.close();
			} catch (Exception e) {
			      e.printStackTrace();
			    } 
		
	}
 
    public void init() {
    	try {		     
			  Connection conn = DriverManager.getConnection(url, user,passwd);
		      Statement state = conn.createStatement();			 						
		      String query="select distinct(ardt) as aro from film";
			  ResultSet result = state.executeQuery(query);
			  String nom1="";
		      while(result.next()){ 
			          nom1 = result.getString("aro");
			   	      c.addItem(nom1);
		      }		   
		      result.close();	
		      state.close();
			} catch (Exception e) {
			      e.printStackTrace();
			    } 
	}
	

//
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
		 Object source = e.getSource();
		 boolean wifi = k2.isSelected();
		 boolean velib = k.isSelected();
		 String ho=hot.getSelectedItem().toString();
		 String cp=c.getSelectedItem().toString();
		 boolean hote=h1.isSelected();
		if(source == b1){
			//VueFilmWifiVelibHotel(ho,cp);
			info.setText("Patientez 10 sec. note: peut ne pas avoir des resultats selon la recherche");		
			
		    if(wifi) { VueFilmWifi(cp);}				
			if(velib){VueFilmVelib(cp);}
		    if(hote) {VueFilmHotel(ho,cp);}
	
			}
		
		if(source == b) {
			deldon();
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			System.exit(0);
		}
	}
		
	
}
