package fenetre;

import java.awt.Graphics;

import javax.swing.ImageIcon;
import javax.swing.JPanel;
/**
 * @author ${AMARA}
 *
 */
public class fond extends JPanel {

	public void paintComponent(Graphics g) {
		g.drawImage(new ImageIcon("src/fond.jpg").getImage(),0,0, this.getSize().width, this.getSize().height, null);
	}

}
