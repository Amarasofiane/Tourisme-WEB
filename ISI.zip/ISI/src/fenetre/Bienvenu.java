package fenetre;

import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 * @author ${AMARA}
 *
 */
public class Bienvenu extends JFrame implements ActionListener {

	String lePseudo;
	private String mdp;
	JLabel bnv = new JLabel();
	Icon img = new ImageIcon("src/java.png");
	
	Toolkit k = Toolkit.getDefaultToolkit();
	Dimension tailleEcran = k.getScreenSize();
	
	JLabel ntpseudo = new JLabel("UserBDD");
	JLabel msgPseudo = new JLabel();
	JTextField pseudo = new JTextField();
	
	JLabel ntMdp = new JLabel("PasswordBDD");
	JLabel msgPasse = new JLabel();
	JTextField motDePasse = new JTextField();
	
	JLabel ntpseudo1 = new JLabel("SourceUrlBDD");
	JLabel msgPseudo1 = new JLabel();
	JTextField pseudo1 = new JTextField();
	
	JButton btn = new JButton("Debut");
	JButton ins = new JButton("Effacer");
	JButton quiter = new JButton("Quiter");
	JPanel pnl = new JPanel();
	
	public Bienvenu() {
		bnv.setIcon(img);
		setLayout(null);
		setTitle("Connextion");
		
		Container container = this.getContentPane();
		pseudo.setPreferredSize(new Dimension(100,25));
		motDePasse.setPreferredSize(new Dimension(100,25));
		pseudo1.setPreferredSize(new Dimension(100,25));

		bnv.setBounds(80, 10, 400, 150);
		pnl.setBounds(100, 150, 300, 120);
	
		btn.setBounds(105, 300, 90, 30);
		btn.addActionListener(this);
		ins.setBounds(205, 300, 90, 30);
		ins.addActionListener(this);
		quiter.setBounds(305,300,90,30);
		quiter.addActionListener(this);
		
		pnl.setBorder(BorderFactory.createTitledBorder("saisissiez les données de votre Driver JDBC"));
	
		pnl.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		
		c.gridx = 0;
		c.gridy = 0;
		pnl.add(ntpseudo,c);

		c.gridx = 1;
		c.gridy = 0;
		pnl.add(pseudo,c);

		msgPseudo.setForeground(Color.red);
		c.gridx = 2;
		c.gridy = 0;

		pnl.add(msgPseudo,c);
		
		
		
		c.gridx = 0;
		c.gridy = 1;
		pnl.add(ntMdp,c);
		c.gridx = 1;
		c.gridy = 1;
		pnl.add(motDePasse,c);
		
		c.gridx = 2;
		c.gridy = 1;
		msgPasse.setForeground(Color.red);
		pnl.add(msgPasse,c);
		
		c.gridx = 0;
		c.gridy = 2;
		pnl.add(ntpseudo1,c);

		c.gridx = 1;
		c.gridy = 2;
		pnl.add(pseudo1,c);

		msgPseudo1.setForeground(Color.red);
		c.gridx = 2;
		c.gridy = 2;

		pnl.add(msgPseudo1,c);
		
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setBounds(tailleEcran.width/2-300,tailleEcran.height/2-200,500,420);
		
		container.add(bnv);
		container.add(pnl);
		container.add(btn);
		container.add(ins);
		container.add(quiter);
		
		setResizable(false);
		setVisible(true);
		
	}
	public boolean conBDD(String url,String user,String passwd) throws ClassNotFoundException {
		  try {
			Class.forName("org.postgresql.Driver");
			// String url = "jdbc:postgresql://localhost:5432/info";
		    // String user = "postgres";
		    //  String passwd = "amara123";
				
					Connection conn = DriverManager.getConnection(url, user, passwd);
					System.out.println("connextion BDD faite");
					return true;
				} catch (SQLException e) {
					// TODO Auto-generated catch block
				return false;				
				}}
	
	public static void main(String[]args) {
		Bienvenu c=new Bienvenu();
	}
	
	@Override
	public void actionPerformed(ActionEvent a) {
		Object source = a.getSource();
		if(source == btn){
			String ps=pseudo.getText();
			String md=motDePasse.getText();
			String url=pseudo1.getText();

			try {
				if(conBDD(url, ps, md)) {
					this.dispose();
					Mediation f=new Mediation(ps,md,url);
					f.remplir();
					
					try {
						Thread.sleep(3000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					f.init();
					f.etoils();
				}else {
					ps="";
					md="";
					pnl.setBorder(BorderFactory.createTitledBorder("données incorrect réessayez"));
				}
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if(source == ins) {
			pseudo.setText("");
			motDePasse.setText("");
		}
		if(source == quiter) {
			System.exit(0);

		}
	}
	
	
}
